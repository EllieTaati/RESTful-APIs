package models;

import java.util.List;


import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "bookList")
@XmlAccessorType(XmlAccessType.FIELD)
public class BookList {
 @XmlElement(name = "book")
 
 private List<Book> booksList;
 
 public BookList() {}
//Constructor with a list of books
 public BookList(List<Book> booksList) {
  this.booksList = booksList;
	}
 //Getter and Setter
 public List<Book> getBooksList() {
  return booksList;
	}
 public void setBooksList(List<Book> booksList) {
  this.booksList = booksList;
  }
 
 }

