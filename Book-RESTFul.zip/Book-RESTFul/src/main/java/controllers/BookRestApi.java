package controllers;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import database.BookDAO;
import models.Book;
import models.BookList;
import utils.AppUtils;

@WebServlet("/bookapi")
public class BookRestApi extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
	
	BookDAO dao = new BookDAO();//Create a new instance of BookDAO
	ArrayList<Book> allBooks = dao.getAllBooks();
	BookList bl = new BookList(allBooks);//Create a BookList object to encapsulate the list of books
	
	String acceptHeader=request.getHeader("Accept");//Get the "Accept" header from the request to identify the desired content type
	// If the requested content type is JSON, convert the BookList object to JSON and send the response
	if(acceptHeader.contains("application/json")) {
		
	   response.setContentType("application/json");
	   String json=AppUtils.convertBookListToJson(bl);
	   response.getWriter().println(json);

	}else if(acceptHeader.contains("text/plain")) {
		// If the requested content type is plain text, convert the BookList object to plain text and send the response
		 response.setContentType("text/plain");
	     String text=AppUtils.convertBookListToPlainText(bl);
	     response.getWriter().println(text);
	}else {
		// If the requested content type is not JSON or text
        // Convert the BookList object to XML and send the response
		response.setContentType("application/xml");
		String xml=AppUtils.convertBookListToXml(bl);
		
		response.getWriter().println(xml);
	}	
	
}
	
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
    String contentType = request.getContentType();//Get the content type of the request
    String data = request.getReader().lines().reduce("", (accumulator, actual) -> accumulator + actual);//Read the request data

    Book book = null;//Declare variables to store the parsed book and the format of the data
    String format = "";
    
        //If the content type is JSON, parse the data as JSON and set the format
    if (contentType.contains("application/json")) {
        book = AppUtils.parseBookFromJson(data);
        format = "JSON";
        //If the content type is XML, parse the data as XML and set the format
    } else if (contentType.contains("application/xml")) {
        book = AppUtils.parseBookFromXml(data);
        format = "XML";
        //If the content type is plain text, parse the data as plain text and set the format
    } else if (contentType.contains("text/plain")) {
        book = AppUtils.parsePlainText(data);
        format = "plain text";
    }

    if (book != null) {
        if (AppUtils.isBookDataValid(book)) {//To check the all fields are not empty 
            BookDAO dao = new BookDAO();

            try {
                // Insert the book into the database
                dao.insertBook(book);
                response.getWriter().write(book.getTitle() + " inserted using " + format + " format!");
            } catch (SQLException e) {
                e.printStackTrace();
                // Send error response
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("Error occurred while inserting the book.");
            }
        } else {
            // Send error response for missing or invalid data
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Please provide all the required fields.");
        }
    } else {
        // Send error response for invalid data format
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.getWriter().write("Invalid data format. Please provide data in JSON, XML, or plain text format.");
    }
}

	
@Override
public void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String contentType = request.getContentType();//Get the content type of the request
    String data = request.getReader().lines().reduce("", (accumulator, actual) -> accumulator + actual);//Read the request data

    Book book = null;
    String format = "";

    //If the content type is JSON, parse the data as JSON and set the format
    if (contentType.contains("application/json")) {
        book = AppUtils.parseBookFromJson(data);
        format = "JSON";
        //If the content type is XML, parse the data as XML and set the format
    } else if (contentType.contains("application/xml")) {
        book = AppUtils.parseBookFromXml(data);
        format = "XML";
      //If the content type is plain text, parse the data as plain text and set the format
    } else if (contentType.contains("text/plain")) {
        book = AppUtils.parsePlainTextForUpdate(data);
        format = "plain text";
    }

    BookDAO dao = new BookDAO();

    dao.updateBook(book);
	response.getWriter().write(book.getTitle() + " updated using " + format + " format!");
}
@Override
protected void doDelete(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
	
	String contentType = request.getContentType();//Get the content type of the request
    String data = request.getReader().lines().reduce("", (accumulator, actual) -> accumulator + actual);//Read the request data
    
    int id = -1;//Initialize id variable with a default value of -1 as a fallback in case the parsing fails or book id is not 
    
  //If the content type is JSON, parse the data as JSON to get the book id
    if (contentType.contains("application/json")) {
        id = AppUtils.parseIdFromJson(data);
      //If the content type is XML, parse the data as XML to get the book id
    } else if (contentType.contains("application/xml")) {
        id = AppUtils.parseIdFromXml(data);
      //If the content type is plain text, parse the data as plain text to get the book id
    } else if (contentType.contains("text/plain")) {
        id = AppUtils.parseIdFromPlainText(data);
    }

    BookDAO dao = new BookDAO();
  //Delete the book from the database
    dao.deleteBook(id);
	response.getWriter().write("Book with ID " + id + " deleted successfully!");
}
}
