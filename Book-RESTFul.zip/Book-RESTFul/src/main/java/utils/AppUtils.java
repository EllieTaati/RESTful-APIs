package utils;



import java.io.StringReader;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import models.Book;
import models.BookList;

public class AppUtils {
	
	//To convert a BookList object to XML
	public static String convertBookListToXml(BookList bookList) {
		try {
			StringWriter writer= new StringWriter();
			 JAXBContext jaxbContext = JAXBContext.newInstance(BookList.class);
		      Marshaller marshaller = jaxbContext.createMarshaller();
		      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		      marshaller.marshal(bookList,writer);
		      return writer.toString();
		}catch(JAXBException e) {
			e.printStackTrace();
			return null;
		}
	}
	//To parse a Book object from XML
	public static Book parseBookFromXml(String xmlString){
		 try {
	    JAXBContext jaxbContext = JAXBContext.newInstance(Book.class);
	    Unmarshaller Unmarshaller = jaxbContext.createUnmarshaller();
	    return (Book) Unmarshaller.unmarshal(new StringReader(xmlString));}
	    catch (JAXBException e) {
            e.printStackTrace();
            return null;
        }
    }	
	//To convert a BookList object to JSON
	public static String convertBookListToJson(BookList bookList) {
		 
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
	    
        return gson.toJson(bookList);
    }
	
	//To parse a Book object from JSON
	 public static Book parseBookFromJson(String json) {
		    Gson gson = new Gson();
		    Book book = gson.fromJson(json, Book.class);
		    return book;
		}

	   //To convert a BookList object to plain text
	 public static String convertBookListToPlainText(BookList bookList) {
		    StringBuilder sb = new StringBuilder();
		    for (Book book : bookList.getBooksList()) {
		        sb.append("ID: ").append(book.getId()).append("\n");
		        sb.append("Title: ").append(book.getTitle()).append("\n");
		        sb.append("Author: ").append(book.getAuthor()).append("\n");
		        sb.append("Date: ").append(book.getDate()).append("\n");
		        sb.append("Genres: ").append(book.getGenres()).append("\n");
		        sb.append("Characters: ").append(book.getCharacters()).append("\n");
		        sb.append("Synopsis: ").append(book.getSynopsis()).append("\n");
		        sb.append("\n"); // add a newline after each book
		    }
		    return sb.toString();
		}
	
	//To parse a Book object from plain text
	  public static Book parsePlainText(String data) {
		    Matcher matcher = Pattern.compile(
		            "Title:\\s*(.*)\\s*Author:\\s*(.*)\\s*Date:\\s*(.*)\\s*Genres:\\s*(.*)\\s*Characters:\\s*(.*)\\s*Synopsis:\\s*(.*)",
		            Pattern.DOTALL).matcher(data);

		    if (!matcher.matches()) {
		        throw new IllegalArgumentException("Invalid input data: " + data);
		    }

		    Book book = new Book();
		    book.setTitle(matcher.group(1));
		    book.setAuthor(matcher.group(2));
		    book.setDate(matcher.group(3));
		    book.setGenres(matcher.group(4));
		    book.setCharacters(matcher.group(5));
		    book.setSynopsis(matcher.group(6));

		    return book;
		}
		
	//To parse a Book object from plain text for update
	 public static Book parsePlainTextForUpdate(String data) {
		    Matcher matcher = Pattern.compile(
		            "ID:\\s*(.*)\\s*Title:\\s*(.*)\\s*Author:\\s*(.*)\\s*Date:\\s*(.*)\\s*Genres:\\s*(.*)\\s*Characters:\\s*(.*)\\s*Synopsis:\\s*(.*)",
		            Pattern.DOTALL).matcher(data);
		    
		    if (!matcher.matches()) {
		        throw new IllegalArgumentException("Invalid input data: " + data);
		    }
		   
		    Book book = new Book();
		  
		    book.setId(Integer.parseInt(matcher.group(1)));
		    book.setTitle(matcher.group(2));
		    book.setAuthor(matcher.group(3));
		    book.setDate(matcher.group(4));
		    book.setGenres(matcher.group(5));
		    book.setCharacters(matcher.group(6));
		    book.setSynopsis(matcher.group(7));

		    return book;
		}
	//To parse the id field from a JSON string
	public static int parseIdFromJson(String json) {
		    JsonElement root = new JsonParser().parse(json);
		    JsonObject jsonObject = root.getAsJsonObject();
		    int id = jsonObject.get("id").getAsInt();
		    return id;
		}
	//To parse the id field from a XML string
	public static int parseIdFromXml(String xmlData) {
		    try {
		        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		        InputSource is = new InputSource();
		        is.setCharacterStream(new StringReader(xmlData));
		        Document doc = builder.parse(is);
		        doc.getDocumentElement().normalize();

		        NodeList nodeList = doc.getElementsByTagName("id");
		        Node node = nodeList.item(0);
		        return Integer.parseInt(node.getTextContent());
		    } catch (Exception e) {
		        e.printStackTrace();
		        return 0;
		    }
		}
	//To parse the id field from a plain text data
	public static int parseIdFromPlainText(String data) {
		    String numericString = data.replaceAll("[^\\d]", "");
		    return Integer.parseInt(numericString);
		}
    //To check the validation of data for inserting a book 
	 public static boolean isBookDataValid(Book book) {
	        return book.getTitle() != null &&
	               book.getAuthor() != null &&
	               book.getDate() != null &&
	               book.getGenres() != null &&
	               book.getCharacters() != null &&
	               book.getSynopsis() != null;
	    }
	}




